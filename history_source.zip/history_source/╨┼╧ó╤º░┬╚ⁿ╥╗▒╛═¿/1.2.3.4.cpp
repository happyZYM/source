#include<cstdio>
#define pi 3.1415926535897
using namespace std;
int main()
{
	double r,c,d,s;
	scanf("%lf",&r);
	c=r*pi;
	d=r*2;
	s=r*r*pi;
	printf("%.4lf %.4lf %.4lf\n",d,c,s);
	return 0;
}

