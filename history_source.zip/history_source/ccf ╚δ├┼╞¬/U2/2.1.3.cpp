#include<iostream>
using namespace std;
int main()
{
	char a='b';
	cout<<a;
	while(true);
}
