#include<cstdio>
using namespace std;
int main()
{
	double a;
	scanf("%lf",&a);
	printf("%.5lf\n",a);
	printf("%e\n",a);
	printf("%g\n",a);
	return 0;
}
