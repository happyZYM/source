#include<cstdio>
int main()
{
	printf("14 23 23 48 56 56 58 95 99 99\n\n7\n");
	return 0;
}
