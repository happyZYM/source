#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	while(true)
	{
		cin>>n;
		cout<<pow(2,n)<<endl<<"============="<<endl;
	}
}
