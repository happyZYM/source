#include<iostream>
using namespace std;
int main()
{
	cout<<"a=202"<<endl;
	cout<<"2*a=404"<<endl;
	cout<<"a=202"<<endl;
	cout<<"2323.343450"<<endl;
	cout<<"             2323.34"<<endl;
	cout<<"2323.34"<<endl;
	cout<<"2323.34"<<endl;
	cout<<"============"<<endl<<endl;
	cout<<"1, 1,001,123,123 ,00123";
	while(true);
}
