#include<iostream>
#include<cmath> 
using namespace std;
int main()
{
	cout<<"ceil(3.14)="<<ceil(3.14)<<" floor(3.14)="<<floor(3.14)<<endl;
	cout<<"4^3.0="<<pow(4,3.0)<<endl;
	cout<<"sqrt(9)="<<sqrt(9)<<endl;
	while(true);
}
