#include<cstdio>
using namespace std;
int main()
{
	double f,c;
	scanf("%lf",&f);
	c=5.0*(f-32.0)/9.0;
	printf("%.5lf\n",c);
	return 0;
}

