#include<iostream>
using namespace std;
int main()
{
	cout<<"y=m*x+b"<<endl;
	cout<<"m=(a+b+c)/(e*f)"<<endl;
	cout<<"a=sqrt((x-3*y)*z)"<<endl;
	cout<<"a=(2*x-y)/(x+pow(y,2))"<<endl;
	cout<<"m=(x-y*z)/(2/c)";
	while(true); 
}
