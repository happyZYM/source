#include<iostream>
using namespace std;
int main()
{
	int a;
	while(true){
		cin>>a;
		a=a*1001;
		cout<<a/7/11/13<<endl;
	}
}
