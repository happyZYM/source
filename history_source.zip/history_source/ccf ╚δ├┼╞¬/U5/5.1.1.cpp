#include<cstdio>
int main()
{
	printf("3 7\n");
	return 0;
}
