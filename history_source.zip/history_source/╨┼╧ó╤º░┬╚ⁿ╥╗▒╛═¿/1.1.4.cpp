#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	char a;
	a=getch();
	cout<<a<<endl;
	cout<<"  "<<a<<endl;
	cout<<" "<<a<<a<<a<<endl;
	cout<<a<<a<<a<<a<<a<<endl;
	return 0;
}
