#include<cstdio>
using namespace std;
int main()
{
	double a,b;
	scanf("%lf%lf",&a,&b);
	printf("%.9lf\n",a/b);
	return 0;
}

