#include<cstdio>
using namespace std;
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d\n",n*(n+1)/2);
	return 0;
}

