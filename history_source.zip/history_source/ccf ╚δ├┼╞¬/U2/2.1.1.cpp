#include<iostream>
using namespace std;
int main()
{
	cout<<"ant\n_3cq\nmy\nfriend\nMycar\nmy_car\nall\na_abc\ndaf_32\nmaxn";
	while(true);
}
