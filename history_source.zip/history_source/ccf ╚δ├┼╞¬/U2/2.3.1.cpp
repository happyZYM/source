#include<iostream>
using namespace std;
int main()
{
	cout<<"3 3\n3 8\n11 8\nc=1\nc=1.375\n";
	while(true);
}
