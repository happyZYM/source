#include<iostream>
using namespace std;
int main()
{
	cout<<"9\n28\n2047\n\n\n";
	cout<<"0\n1\n12\n\n\n";
	cout<<"9\n28\n2047";
	while(true);
}
