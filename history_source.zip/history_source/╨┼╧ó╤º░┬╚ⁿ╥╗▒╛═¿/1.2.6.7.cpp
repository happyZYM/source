#include<cstdio>
using namespace std;
int main()
{
	long long a,b,c;
	scanf("%ld%ld",&a,&b);
	c=a*b;
	printf("%ld\n",c);
	return 0;
}

