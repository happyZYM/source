#include<iostream>
using namespace std;
int main()
{
	cout<<"A:"<<endl;
	cout<<"B:x=2"<<endl;
	cout<<"C:z =7"<<endl;
	cout<<"D:x=2"<<endl;
	cout<<"E:z =6";
	while(true);
}
