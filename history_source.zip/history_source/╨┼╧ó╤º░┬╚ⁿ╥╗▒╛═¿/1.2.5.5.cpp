#include<iostream>
using namespace std;
int main()
{
	char a;
	scanf("%c",&a);
	cout<<"  "<<a<<endl;
	cout<<" "<<a<<a<<a<<endl;
	cout<<a<<a<<a<<a<<a<<endl;
	cout<<" "<<a<<a<<a<<endl;
	cout<<"  "<<a<<endl;
	return 0;
}

