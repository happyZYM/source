#include<iostream>
using namespace std;
int main()
{
	cout<<"0\n\n25\n\n1#\n2$\n3\n4\n5\n\n25:28\n67:70";
	while(true);
} 
