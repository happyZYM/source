#include<cstdio>
int main()
{
	printf("1 2 3 4 5 6 7 8 9\n");
	printf("18 17 16 15 14 13 12 11 10\n");
	printf("19 20 21 22 23 24 25 26 27\n");
	printf("36 35 34 33 32 31 30 0 0\n");
	printf("37 38 39 40 41 42 43 44 45\n");
	printf("54 53 52 51 50 0 0 0 0\n");
	printf("55 56 57 58 59 60 61 62 63\n");
	printf("72 71 70 0 0 0 0 0 0\n");
	return 0;
}
