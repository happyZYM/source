#include<cstdio>
#define pi 3.14
using namespace std;
int main()
{
	double r;
	scanf("%lf",&r);
	printf("%.2lf\n",4.0/3.0*pi*r*r*r);
	return 0;
}

