#include<cstdio>
int main()
{
	printf("TCCCCCCCCCCCCCCCCCCCCCCCCC\n\n");
	printf("I HAVE A DREAM.\n15\n\n\n");
	printf("f\nsof\n\n\n");
	printf("9.87654\n1.23457\n");
	return 0;
}
