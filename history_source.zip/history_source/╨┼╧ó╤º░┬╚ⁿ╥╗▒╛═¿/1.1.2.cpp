#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cin>>b>>a>>b;
	cout<<a<<endl;
	return 0;
}
