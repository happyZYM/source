#include<cstdio>
using namespace std;
int main()
{
	double a;
	scanf("%lf",&a);
	printf("%.3lf\n",a);
	return 0;
}

