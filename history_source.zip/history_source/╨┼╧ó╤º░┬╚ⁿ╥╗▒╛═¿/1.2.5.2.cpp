#include<cstdio>
using namespace std;
int main()
{
	double a;
	scanf("%lf",&a);
	printf("%.12lf\n",a);
	return 0;
}

