#include<iostream>
using namespace std;
int main()
{
	cout<<"001 0\n\n50 1 0\n\n8";
	while(true);
} 
