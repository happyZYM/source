#include<iostream>
using namespace std;
int main()
{
	cout<<"11\n9\n10\n9\n10\n10\n50\n21";
	while(true);
} 
