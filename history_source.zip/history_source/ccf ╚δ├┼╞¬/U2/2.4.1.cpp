#include<iostream>
using namespace std;
int main()
{
	float a;
	while(true){
		cin>>a;
		cout<<a<<"�H"<<"="<<(a-32)/1.8<<"��"<<endl; 
	}
}
