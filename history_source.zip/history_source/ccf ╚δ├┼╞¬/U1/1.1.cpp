//1.1.1
#include<iostream>
using namespace std;
int main()
{
	cout<<"I love programming"<<endl;
	while(true){;
	}
return 0;
}
