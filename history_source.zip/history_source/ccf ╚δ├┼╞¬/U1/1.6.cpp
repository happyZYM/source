#include<iostream>
using namespace std;
int main()
{
long double d;
d=0.6/5;
cout<<"��16֧Ǧ��Ҫ"<<d*16<<"ԪǮ";
while(true);
}
