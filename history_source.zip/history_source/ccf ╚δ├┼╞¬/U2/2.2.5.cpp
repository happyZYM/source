#include<iostream>
using namespace std;
int main()
{
	cout<<"4 3 4\n4 4 3"<<endl<<endl<<"==========="<<endl;
	cout<<"2 1";
	while(true);
} 
