#include<iostream>
using namespace std;
int main()
{
	cout<<"0 4201 987654321\n\n000  \n\n50 1 1";
	while(true);
} 
