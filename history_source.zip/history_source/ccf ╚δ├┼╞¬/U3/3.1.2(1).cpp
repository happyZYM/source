#include<iostream>
#include<cmath>
using namespace std; 
int main()
{
	int a,b,c=0,d=0;
	cout<<"a,b=";
	cin>>a>>b;
	if(a>b)
	{
		c=a/b;
		d=a%b;
	} 
	cout<<c+d;
	while(true);
}
