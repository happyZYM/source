#include<cstdio>
using namespace std;
int main()
{
	char a;
	int b;
	double c,d;
	scanf("%c%d%lf%lf",&a,&b,&c,&d);
	printf("%c %d %.6lf %.6lf\n",a,b,c,d);
	return 0;
}

