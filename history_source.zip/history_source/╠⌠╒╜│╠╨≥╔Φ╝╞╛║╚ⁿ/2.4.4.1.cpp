#include<cstdio>
void solve()
{
	
}
void init()
{
	
}
int main()
{
	return 0;
}
