#include<iostream>
using namespace std;
int main()
{
	cout<<"B,C";
	while(true);
} 
