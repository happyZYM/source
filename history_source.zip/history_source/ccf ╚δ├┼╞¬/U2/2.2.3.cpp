#include<iostream>
using namespace std;
int main()
{
	cout<<"C,E,F";
	while(true);
} 
