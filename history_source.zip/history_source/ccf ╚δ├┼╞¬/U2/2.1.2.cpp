#include<iostream>
using namespace std;
int main()
{
	int a=998;
	float b=3.1415926535897;
	char c='a';
	double d=1.0/3;
	long double e=8.0/9;
	long f=999999999999999999999;
	cout<<a<<endl<<b<<endl<<c<<endl<<d<<endl<<e<<endl<<f<<endl;
	
	while(true);
	
	return 0;
}
