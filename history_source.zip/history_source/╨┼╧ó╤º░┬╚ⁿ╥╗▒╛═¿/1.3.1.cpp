#include<cstdio>
using namespace std;
int main()
{
	int n;
	scanf("%d",&n);
	if(n&1&&n!=7) printf("NO\n");
	else printf("YES\n"); 
	return 0;
}

